using AplicacionNetRazor.Datos;
using AplicacionNetRazor.Modelos;
using AplicacionNetRazor.Modelos.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace AplicacionNetRazor.Pages.Categorias
{
    public class BorrarModel : PageModel
    {
        private readonly AplicacionDBContext _contexto;
        public BorrarModel(AplicacionDBContext context)
        {
            _contexto = context;
        }

        [BindProperty]
        public Categoria Categoria { get; set; }
        public string Mensaje { get; set; }
        public string Nombre { get; set; }

        public async void OnGet(int id)
        {
            Categoria = await _contexto.Categoria.FindAsync(id);
            Nombre = Categoria.Nombre;
        }

        public async Task<IActionResult> OnPost()
        {
            var CategoriaBD = await _contexto.Categoria.FindAsync(Categoria.Id);
            if (CategoriaBD != null)
            {
                CategoriaBD.Estado = !CategoriaBD.Estado;
                await _contexto.SaveChangesAsync();
                Mensaje = "Categoria borrada";
                return RedirectToPage("Index");
            }
            return NotFound();

        }
    }
}