using AplicacionNetRazor.Datos;
using AplicacionNetRazor.Modelos;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AplicacionNetRazor.Pages.Categorias
{
    public class EditarModel : PageModel
    {
        private readonly AplicacionDBContext _contexto;

        public EditarModel(AplicacionDBContext contexto)
        {
            _contexto = contexto;
        }

        [BindProperty]
        public Categoria Categoria { get; set; }
        public async void OnGet(int id)
        {
            Categoria = await _contexto.Categoria.FindAsync(id);
        }

        public async Task<IActionResult> OnPost()
        {
            var CategoriaDesdeBd = await _contexto.Categoria.FindAsync(Categoria.Id);
            CategoriaDesdeBd.Nombre = Categoria.Nombre;
            CategoriaDesdeBd.FechaCreacion = Categoria.FechaCreacion;

            await _contexto.SaveChangesAsync();
            return RedirectToPage("Index");
        }
    }
}