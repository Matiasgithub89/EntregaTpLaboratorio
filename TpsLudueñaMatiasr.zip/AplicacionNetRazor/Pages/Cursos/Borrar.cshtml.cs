using AplicacionNetRazor.Datos;
using AplicacionNetRazor.Modelos;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AplicacionNetRazor.Pages.Cursos
{
    public class BorrarModel : PageModel
    {
        private readonly AplicacionDBContext context;
        public BorrarModel(AplicacionDBContext _context)
        {
            this.context = _context;
        }

        [BindProperty]
        public Curso? Curso { get; set; }
        public string Mensaje { get; set; }
        public string Nombre { get; set; }
        public async Task OnGet(int id)
        {
            Curso = await context.Curso.FindAsync(id);
            Nombre = Curso.NombreCurso;
        }
        public async Task<IActionResult> OnPost()
        {
            var CursoBorrar = await context.Curso.FindAsync(Curso.Id);
            CursoBorrar.Estado = !CursoBorrar.Estado;
            await context.SaveChangesAsync();
            Mensaje = "Curso modificado exitosamente";
            return RedirectToPage("Index");
        }
    }
}