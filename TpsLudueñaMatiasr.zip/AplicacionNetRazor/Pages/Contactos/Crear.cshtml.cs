using AplicacionNetRazor.Datos;
using AplicacionNetRazor.Modelos.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace AplicacionNetRazor.Pages.Contactos
{
    public class CrearModel : PageModel
    {
        private readonly AplicacionDBContext _contexto;

        public CrearModel(AplicacionDBContext contexto)
        {
            _contexto = contexto;
        }

        [BindProperty]

        public CrearContactoVM ContactoVm { get; set; }
        public async Task<IActionResult> OnGet()
        {
            ContactoVm = new CrearContactoVM()
            {
                ListaCategorias = await _contexto.Categoria.ToListAsync(),
                Contacto = new Modelos.Contacto()
            };
            return Page();
        }

        public async Task<IActionResult> OnPost()
        {

            //ContactoVm.ListaCategorias = await _contexto.Categoria.ToListAsync();

            await _contexto.Contacto.AddAsync(ContactoVm.Contacto);
            await _contexto.SaveChangesAsync();
            return RedirectToPage("Index");
        }
    }
}
