using AplicacionNetRazor.Datos;
using AplicacionNetRazor.Modelos.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace AplicacionNetRazor.Pages.Contactos
{
    public class BorrarModel : PageModel
    {
        private readonly AplicacionDBContext _contexto;
        public BorrarModel(AplicacionDBContext contexto)
        {
            _contexto = contexto;
        }

        [BindProperty]

        public CrearContactoVM ContactoVm { get; set; }

        public async Task<IActionResult> OnGet(int id)
        {
            ContactoVm = new CrearContactoVM()
            {
                ListaCategorias = await _contexto.Categoria.ToListAsync(),
                Contacto = await _contexto.Contacto.FindAsync(id)
            };
            return Page();
        }

        public async Task<IActionResult> OnPost()
        {
            var ContactoDesdeDb = await _contexto.Contacto.FindAsync(ContactoVm.Contacto.Id);

            ContactoDesdeDb.Estado = !ContactoDesdeDb.Estado;

            await _contexto.SaveChangesAsync(); 

            return RedirectToPage("Index");
            
        }

    }
}