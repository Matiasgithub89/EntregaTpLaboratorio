using AplicacionNetRazor.Datos;
using AplicacionNetRazor.Modelos;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AplicacionNetRazor.Pages.Alumnos
{
    public class BorrarModel : PageModel
    {
        private readonly AplicacionDBContext _contexto;
        public BorrarModel(AplicacionDBContext contexto)
        {
            _contexto = contexto;
        }

        [BindProperty]
        public Alumno Alumno { get; set; }

        [TempData]
        public string Mensaje { get; set; }
        public string Nombre { get; set; }
        public async Task OnGet(int id)
        {
            Alumno = await _contexto.Alumno.FindAsync(id);
            Nombre = Alumno.Apellido;
        }

        public async Task<IActionResult> OnPost()
        {
            var AlumnoBorrar = await _contexto.Alumno.FindAsync(Alumno.IdAlumno);
            AlumnoBorrar.Estado = !AlumnoBorrar.Estado;
            await _contexto.SaveChangesAsync();
            Mensaje = "Alumno Dado de Baja correctamente";
            return RedirectToPage("Index");
        }
    }
}