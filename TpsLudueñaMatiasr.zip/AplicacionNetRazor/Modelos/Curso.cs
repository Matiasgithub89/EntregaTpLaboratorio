﻿
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace AplicacionNetRazor.Modelos
{
    public class Curso
    {
        [Key]
        public int Id { get; set; }

        [Required]  
        [Display(Name ="Nombre del curso")]
        public string NombreCurso { get; set; }
        [Display(Name = "Cantidad de clases")]
        public int CantidadClases { get; set; }
        public int Precio { get; set; }
        [Display(Name = "Fecha de creación")]
        [BindProperty, DataType(DataType.Date)]
        public DateTime FechaCreacion { get; set; }
        [Required]
        [Display(Name = "Estado")]
        public bool Estado { get; set; } = true;


    }
}
