﻿namespace AplicacionNetRazor.Modelos.ViewModels
{
    public class CrearContactoVM
    {
        public List<Categoria> ListaCategorias { get; set; }
        public Contacto Contacto { get; set; }
    }
}
